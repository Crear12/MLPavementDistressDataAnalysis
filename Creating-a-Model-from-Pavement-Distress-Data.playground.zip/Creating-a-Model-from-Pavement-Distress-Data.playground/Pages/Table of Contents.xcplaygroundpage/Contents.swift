/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Table of Contents
*/
/*:
 # Creating a Model from Tabular Data
 ## Table of Contents
 - [Train a Regressor and a Classifier](Train%20a%20Regressor%20and%20a%20Classifier)
 - [LICENSE](LICENSE)
 ****
 [Next](@next)
 */
